package com.dao;

import com.pojo.BookFunEntity;

import java.util.List;

public  interface  BookMapper {

     List<BookFunEntity> selectbook();

}
