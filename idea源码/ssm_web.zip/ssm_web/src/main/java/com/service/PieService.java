package com.service;

import org.jfree.chart.JFreeChart;

public interface PieService {
    public JFreeChart createPieTools();
}
