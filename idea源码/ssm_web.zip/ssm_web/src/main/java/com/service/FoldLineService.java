package com.service;

import org.jfree.chart.JFreeChart;

public interface FoldLineService {
    public JFreeChart createFoldLineTools();
}
