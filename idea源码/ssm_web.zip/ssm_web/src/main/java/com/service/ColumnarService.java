package com.service;

import org.jfree.chart.JFreeChart;

public interface ColumnarService {
    public JFreeChart createColumnarTools();
}
